# A Methodological Approach for the Effective Modeling of Bayesian Networks
# Martin Atzmueller and Florian Lemmerich
# KI 2008: Advances in Artificial Intelligence: 31st Annual German Conference
# Section 6. Case Study
# first column to match
# 0-10  10-30 30-60   >60
# 0.433 0.464 0.099 0.0040
# Note: the "inverse" of x1 is used
# -- Atzmueller & Lemmek4rich [begin] -- #
nodes = '[
{"id":1,"name":"x1","type":"state","specification":{"bbn":{"levels":["false","true"],"vpar":[1],"values":[1,1],"prob":[0.5,0.5],"evidence":[0.5,0.5],"use_evidence":"false"}}},
{"id":2,"name":"x2","type":"state","specification":{"bbn":{"levels":["none","some","full"],"vpar":[2],"values":[1,1,1],"prob":[0.333,0.333,0.333],"evidence":[0.333,0.333,0.333],"use_evidence":"false"}}},
{"id":3,"name":"y","type":"state","specification":{"bbn":{"type":"tnorm","mean":"(10*x1+20*x2)","var":0.0333,"levels":["0-10","10-30","30-60",">60"],"vpar":[3,1,2],"values":[0,0,0.15,0.85,0.5,0.5,0,0,0.25,0.75,0,0,0.9,0.1,0,0],"prob":[0.25,0.25,0.25,0.25],"evidence":[0.25,0.25,0.25,0.25],"use_evidence":"false"}}}
]'

rjson::fromJSON('{"Staff": 5, "Testing": 5}')

nodes = '{"mu":"(10*x1+20*x2)","n":{"y":4,"x1":2,"x2":3}}'
nodes = rjson::fromJSON(nodes)
n.vpar =  nodes$n[-1]
n.y = nodes$n[[1]]
vpar.names = names(nodes$n)
names(vpar.names) = names(nodes$n)
mu = nodes$mu

tnorm = function(target.id,nodes){
  vpar.names = NULL
  vpar.n = NULL
  for(i in 1:length(nodes)){
    if(nodes[[i]]$id == target.id){
      vpar = nodes[[i]]$specification$bbn$vpar[-1]
      mu.fn = nodes[[i]]$specification$bbn$mean
    }else{
      vpar.names = c(vpar.names,nodes[[i]]$name)
      vpar.n = c(vpar.n,length(nodes[[i]]$specification$bbn$levels))
    }
  }
  names(vpar.names) = vpar.names
  names(vpar.n) = vpar.names


  tmeans = expand.grid.tnorm(n=n.vpar)
  mu.normalizer = max(with(expand.grid(lapply(vpar.names,function(x)c(0,1))),eval(parse(text=mu))))
  tsd = sqrt(1/mu.normalizer)
  tmeans = with(tmeans,eval(parse(text=mu)))/mu.normalizer
  cpt = sapply(tmeans,function(tmean){
    normalizer = diff(pnorm(c(0,1),tmean,tsd))
    (pnorm((1:nY)/nY,tmean,tsd)-pnorm((0:(nY-1))/nY,tmean,tsd))/normalizer
    }
  )
  nodes[[i]]$specification$bbn$values = as.vector(t(cpt))
  as.vector(t(cpt))
}


length(nodes[[3]]$specification$bbn$values)
paste(tnorm(3,nodes),collapse=",")






data1 <- jsonlite::fromJSON("https://api.github.com/users/hadley/repos")
jsonlite::flatten(data1)

tmean.fn = '10*x1+20*x2'
tmp = lapply(nodes,function(node){
  print(node$id)
  print(node$specification$bbn$vpar)
  assign(node$name,node$specification$bbn$levels,envir = .GlobalEnv)
  data.frame(id=node$id,n=length(node$specification$bbn$levels),name=node$name)
})
as.data.frame(do.call("rbind",tmp))

nodes$id
vpar
tmeans = expand.grid.tnorm(n=c(x1=n.x1,x2=n.x2))
equation = "10*x1 + 20*x2"
normalizer = max(with(expand.grid(lapply(c(x1="x1",x2="x2"),function(x)c(0,1))),eval(parse(text=equation))))
tmeans = with(tmeans,eval(parse(text=equation)))/normalizer
cpt = (sapply(tmeans,function(tmean){
  normalizer = diff(pnorm(c(0,1),tmean,tsd))
  (pnorm((1:n.y)/n.y,tmean,tsd)-pnorm((0:(n.y-1))/n.y,tmean,tsd))/normalizer
}
))
cpt


cats.y = c("0-10","10-30","30-60",">60")
cats.x1 = c("True","False")
cats.x2 = c("none","some","full")
match.y = c(0.433,0.464,0.099,0.0040) # mu.weights=c(10,20),mu.offset=-0.1,inverse.x=c(TRUE,FALSE)
match.y = c(0.54531264,0.3775393,0.07348527,0.0036627667); # mu.weights=c(10,20),mu.offset=0,inverse.x=c(FALSE,FALSE)
cpt = tnorm(cats.y,cats.x1,cats.x2,mu.weights=c(10,20),mu.offset=0,inverse.x=c(FALSE,FALSE))
cpt[1,1,]
1/sum(mu.weights)
# -- Atzmueller & Lemmerich [end] -- #

# Risk Assessment and Decision Analysis with Bayesian Networks
# Fenton and Neil
# Chapter 8.5 example
# first column to match
#  Very Low      Low       Medium      High      Very High
# 0.77912056 0.21627662 0.004598874 3.945603E-6 9.05511E-11
# -- Fenton & Neil [begin] -- #
cats.y  = c("Very Low","Low","Medium","High","Very High")
cats.x1 = c("Very Low","Low","Medium","High","Very High")
cats.x2 = c("Very Low","Low","Medium","High","Very High")
match.y = c(0.77912056,0.21627662,0.004598874,3.945603E-6,9.05511E-11)
tnorm(cats.y,cats.x1,cats.x2,c(8,2),0,tsd=sqrt(0.01))
# -- Fenton & Neil [end] -- #

# --- function to calculate CPT based on a graph with 2 parents and 1 tnorm target
tnorm = function(cats.y,cats.x1,cats.x2,mu.weights=c(1,1),mu.offset=0,tsd=NULL,inverse.x=c(FALSE,FALSE)){
  require(truncnorm)
  if(is.null(tsd)) tsd = sqrt(1/sum(mu.weights))
  n.y  = length(cats.y)
  n.x1 = length(cats.x1)
  n.x2 = length(cats.x2)
  cpt = array(NA, c(n.x1, n.x2, n.y))
  dimnames(cpt) = list(cats.x1,cats.x2,cats.y)
  Im.x1 = (2*(1:n.x1)-1)/(2*n.x1)
  Im.x2 = (2*(1:n.x2)-1)/(2*n.x2)
  if(inverse.x[1]) Im.x1 = rev(Im.x1)
  if(inverse.x[2]) Im.x2 = rev(Im.x2)

  i=1
  for(x1 in 1:n.x1){ # x1 = 1
    for(x2 in 1:n.x2){ # x2 = 1
      tmean = sum(mu.weights * c(Im.x1[x1],Im.x2[x2]))/sum(mu.weights) #+ mu.offset
      #tmean = tmeans[i]
      normalizer = diff(pnorm(c(0,1),tmean,tsd))
      cpt[x1,x2,] =
        (pnorm((1:n.y)/n.y,tmean,tsd)-pnorm((0:(n.y-1))/n.y,tmean,tsd))/normalizer
      cat(format(c("target",cats.y),width=10),"\n",
          format(c("paper",round(match.y,4)),width=10),"\n",
          format(c("cpt",round(cpt[1,1,],4)),width=10),"\n",
          format(c("diff",round(cpt[1,1,]-match.y,4)),width=10)
      )
    }
  }
  cpt
}



expand.grid.tnorm = function (n, mu.weights=NULL)
{
  args = sapply(n,function(n)(2*(1:n)-1)/(2*n))
  nargs <- length(args) #length(args <- list(...))
  if(is.null(mu.weights)) mu.weights = rep(1,nargs)
  cargs <- vector("list", nargs)
  names(cargs) = names(n)
  iArgs <- seq_len(nargs)
  rep.fac <- 1L
  d <- lengths(args)
  orep <- prod(d)
  for (i in iArgs) {
    x <- args[[i]]
    nx <- length(x)
    orep <- orep/nx
    x <- x[rep.int(rep.int(seq_len(nx), rep.int(rep.fac, nx)), orep)]
    cargs[[i]] <- x * mu.weights[i]
    rep.fac <- rep.fac * nx
  }
  rn <- .set_row_names(as.integer(prod(d)))
  structure(cargs, class = "data.frame", row.names = rn)
}


array(c(1,0), c(4,2))


,eval(parse(text="10*x1 + 20*x2")))


apply(tmeans,1,function(data){
    with(data,eval(parse(text="10*x1 + 20*x2")))
  }
)



tmeans = expand.grid.tnorm(n=c(n.x1,n.x2),c(10,20))
rowSums(tmeans)
tmean = (tmeans[[1]][2]*10 + tmeans[[2]][1]*20)/30
tmean = sum(mu.weights * c(Im.x1[x1],Im.x2[x2]))/sum(mu.weights) + mu.offset
normalizer = diff(pnorm(c(0,1),tmean,tsd))
cpt[x1,x2,] = (pnorm((1:n.y)/n.y,tmean,tsd)-pnorm((0:(n.y-1))/n.y,tmean,tsd))/normalizer

sapply(c(x1=n.x1,x2=n.x2),function(n)c((2*(1:n)-1)/(2*n),0,1))

tmean
normalizer = diff(


  pnorm(c(0,1),tmean,tsd)
  pnorm(c(0,1),tmeans,tsd)

  )
cpt[x1,x2,] = (pnorm((1:n.y)/n.y,tmean,tsd)-pnorm((0:(n.y-1))/n.y,tmean,tsd))/normalizer




      for(y in 1:n.y){ # y = 2
        probP1 = ptruncnorm((y-1)/n.y,0,1,tmean,tsd)
        probP2 = ptruncnorm(y/n.y,0,1,tmean,tsd)
        probP2 - probP1

        (y-1)/n.y
        y/n.y

        diff(
          pnorm(c((y-1)/n.y,y/n.y),tmean,tsd)
          )/

        (0:n.y)/n.y





        #diff(ptruncnorm(c((1:y-1)/n.y,(1:y)/n.y),0,1,tmean,tsd))

        cpt[x1,x2,y] = probP2- probP1
        # cat(format((y-1)/n.y,width=3),"to",format(y/n.y,width=3),": ",format(round(cpt[x1,x2,y],6),width=10,digits=6),"\n")
      }
    }
  }
  cat(format(c("target",cats.y),width=10),"\n",
      format(c("paper",round(match.y,4)),width=10),"\n",
      format(c("cpt",round(cpt[1,1,],4)),width=10),"\n",
      format(c("diff",round(cpt[1,1,]-match.y,4)),width=10)
  )
  invisible(cpt)
}
