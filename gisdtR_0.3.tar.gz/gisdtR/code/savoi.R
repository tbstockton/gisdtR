
savoi = function(response.df,independent.df,schema=NULL,theseNodes=graph.nodes,siCrit=5,nVarsMax=6,response.label="Value"){
  library(gbm);

  sa.gbm = gbm.fit(y=response.df,x=independent.df,distribution="gaussian",n.trees=1000,verbose=FALSE,interaction.depth=10)
#  sa.gbm = gbm.fit(y=response.df[,-2],x=independent.df,distribution="gaussian",n.trees=1000,verbose=FALSE,interaction.depth=10)
  saIndices.df = as.data.frame(summary(sa.gbm,plotit=F))
  nVars = ifelse(sum(saIndices.df$rel.inf>siCrit)<nVarsMax,sum(saIndices.df$rel.inf>siCrit),nVarsMax)
  saIndices.df = saIndices.df[1:nVars,]
  saIndices.df$rel.inf = signif(saIndices.df$rel.inf,2)
  names(saIndices.df)[2] = "Variation Index"
  saIndices.df = merge(saIndices.df,theseNodes[,c("name","type")],by.x="var",by.y="name",sort=FALSE)
  sa.gbm$si = saIndices.df
return(sa.gbm)

  width=800;height=250;
  siBarChartID = paste("g",round(runif(1,10000,20000),0),sep="")
  siBarChart = extJSChart(x="Variation Index",y="var",saIndices.df,xTitle="Variation Index",width=width,height=height,renderTo=siBarChartID)

  siBarChartHtml = paste(
    "<style>",
    ".sa-table{padding:0px 10px;margin:0;text-align:left;}",
    ".sa-param{color:#084594;font-weight:normal}",
    ".sa-value{color:darkred;font-weight:normal}",
    "</style>",
    "<h2>Estimation Uncertainty and Reliability Analysis</h2>",
    "<p class='sa-table'>The Variation Index indicates the proportion of the variation in your scenario's <span class='sa-value'>",response.label,"</span> explained by an input. ",
    "<span class='sa-param'>",saIndices.df$var[1],"</span> ",
    "has the most impact on <span class='sa-value'>",response.label,"</span>",
    "The charts", # for <span class='sa-param'>",saIndices.df$var[1],"</span>",
    " below provide an indication of how reducing the uncertainty in an input", #<span class='sa-param'>",saIndices.df$var[1],"</span>",
    " will impact <span class='sa-value'>",response.label,"</span>.</p>",
    paste("<div id='",siBarChartID,"' style='padding:0;margin:0;width:",width,"px;height:",height,"px;'></div>",sep=""))
    pdScatterChartHtml = paste(
    "<p class='sa-table'>These charts show the change in <span class='sa-value'>",response.label,"</span> with a change in an input. </p>",
    sep="")
  width=800;height=400;
  theseCharts = paste("chart0=Ext.create('Ext.chart.Chart',",siBarChart,");",sep="")
  pdScatterChartChartHtml = ""
  for(i in 1:nVars){ # i = 2    plot(sa.gbm,i.var=3)
    if((i %% 2) == 1){ pdScatterChartChartHtml = paste(pdScatterChartChartHtml,"",sep="") }
    thisSaPd.df = signif(plot(sa.gbm,i.var=as.character(saIndices.df$var[i]),continuous.resolution = 100,return.grid=TRUE),4)

    thisVar = names(thisSaPd.df)[1]
    thisVarClass = saIndices.df$type[i]
    thisChartID = paste("g",round(runif(1,10000,20000),0),sep="")
    names(thisSaPd.df)[2] = response.label # "Value"
    if(thisVarClass == "option"){
      thisSaPd.df = as.data.frame(cbind(unique(thisSaPd.df[,response.label]),as.character(unique(independent.df[,thisVar]))))
      names(thisSaPd.df) = c(response.label,thisVar)
      thisSaPd.df[,response.label] = as.numeric(as.character(thisSaPd.df[,response.label]))
      thisChart = extJSChart(x=thisVar,y=response.label,type="column",data=thisSaPd.df,
                             yMin=min(pretty(thisSaPd.df[,response.label])),yMax=max(pretty(thisSaPd.df[,response.label])),
                             yTitle=response.label,xTitle=thisVar,width=width/2,height=height,renderTo=thisChartID)
      pdScatterChartChartHtml = paste(pdScatterChartChartHtml,
                                      paste("<div id='",thisChartID,"' style='padding:0;margin:0;width:",width/1.75,"px;height:",height,"px;'></div>",sep=""),
                                      "<p class='sa-table'>",thisVar," is a decison option.</p>",
                                      sep="")
    }else{
      dens = density(independent.df[,thisVar])
      xMin = min(pretty(thisSaPd.df[,thisVar]))
      xMax = max(pretty(thisSaPd.df[,thisVar]))
      yMin = min(pretty(thisSaPd.df[,response.label]))
      yMax = max(pretty(thisSaPd.df[,response.label]))

      dens$y = (dens$y-min(dens$y))/diff(range(dens$y)) * diff(range(thisSaPd.df[,response.label]))+min(thisSaPd.df[,response.label])
      dens = data.frame(x=dens$x,y=dens$y)
      thisSaPd.df$density = approx(dens$x,dens$y,thisSaPd.df[,thisVar])$y
      response.quantile = quantile(response.df,c(0.0,0.25,0.5,0.75,1.0))
      response.quantile[which(response.quantile < yMin)] = yMin
      response.quantile[which(response.quantile > yMax)] = yMax

      thisSaPd.df$min = response.quantile[[1]]
      thisSaPd.df$p25th = response.quantile[[2]]
      thisSaPd.df$p50th = response.quantile[[3]]
      thisSaPd.df$p75th = response.quantile[[4]]
      thisSaPd.df$max = response.quantile[[5]]

      names(thisSaPd.df)[grepl(thisVar,names(thisSaPd.df))] = gsub("_"," ",thisVar)
      thisVar = gsub("_"," ",thisVar)
      chartY = c("min","p25th","p50th","p75th","max",paste(thisVar,"density"),response.label)
      chartType = list(min="line",p25th="line",p50th="line",p75th="line",max="line",density="line",Value="line")
      names(chartType)[grepl("Value",names(chartType))] = response.label
      names(chartType)[grepl("density",names(chartType))] = paste(thisVar,"density")
      chartFill = list(min="true",p25th="true",p50th="true",p75th="true",max="true",density="true",Value="false")
      names(chartFill)[grepl("Value",names(chartFill))] = response.label
      names(chartFill)[grepl("density",names(chartFill))] = paste(thisVar,"density")
      names(thisSaPd.df)[grepl("density",names(thisSaPd.df))] = paste(thisVar,"density")
      thisChart = extJSChart(y=chartY,x=thisVar,data=thisSaPd.df,width=width,height=height,
                             type=chartType,fill=chartFill,
                             yTitle=response.label,xTitle=thisVar,
                             #yLabel="{renderer: Ext.util.Format.numberRenderer('0,0.0')}",
                             yMin=min(pretty(thisSaPd.df[,response.label])),yMax=max(pretty(thisSaPd.df[,response.label])),
                             xMin=min(pretty(thisSaPd.df[,thisVar])),xMax=max(pretty(thisSaPd.df[,thisVar])),
                             legend="true",
                             renderTo=thisChartID,returnHtml=FALSE)

      pdScatterChartChartHtml = paste(pdScatterChartChartHtml,
                                      paste("<div id='",thisChartID,"' style='padding:0;margin:0;width:",width,"px;height:",height,"px;'></div>",sep=""),
#                                       "<p class='sa-table'><span class='sa-param'>",thisVar,"</span> impacts <span class='sa-value'>",response.label,"</span> between ",
#                                       min(thisSaPd.df[,2])," and ",max(thisSaPd.df[,2]),". If uncertainty in ",
#                                       "<span class='sa-param'>",thisVar,"</span> ",
#                                       "could be reduced to zero, <span class='sa-value'>",response.label,"</span> would change by ",
#                                       signif(diff(range(thisSaPd.df[,2])),2),
#                                       ".</p>",
                                      sep="")
    }
    theseCharts = paste(theseCharts,"chart",gsub(" ","_",thisVar),"=Ext.create('Ext.chart.Chart',",thisChart,");",sep="")
    if((i %% 2) == 0){ pdScatterChartChartHtml = paste(pdScatterChartChartHtml,sep="") }
  }  # for(i in 1:nVars)
  pdScatterChartHtml = paste(pdScatterChartHtml,pdScatterChartChartHtml,sep="")
  chartMerge = paste(siBarChartHtml,pdScatterChartHtml,"<script>",theseCharts,"</script>")
  if(!is.null(schema)){
    pg.spi.exec(paste("UPDATE ",schema,".","results"," SET result = $_$",chartMerge,"$_$ WHERE name = ","'global_sa'",sep=""))
  }
  invisible(chartMerge)
}
