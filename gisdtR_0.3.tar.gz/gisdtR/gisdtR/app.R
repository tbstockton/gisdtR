#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# Define UI for application that draws a histogram
ui <- shinyUI(fluidPage(

   # Application title
   titlePanel("BayesNet"),
   input$fn = "bayesnet(nodes)",
   mainPanel(textOutput('bayesnet'))


))

# Define server logic required to draw a histogram
server <- shinyServer(function(input, output) {

  output$bayesnet <- renderPrint({
    library(gisdtR)
    nodes = '[{"id":6,"name":"Has tuberculosis","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"vpar":[6,9],"levels":["True","False"],"values":[0.05,0.95,0.01,0.99],"prob":[0.5,0.5],"evidence":[0.5,0.5],"use_evidence":false,"posterior":{"True":0.0104,"False":0.9896}}}},{"id":7,"name":"Has lung cancer","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"vpar":[7,10],"levels":["True","False"],"values":[1,9,1,99],"prob":[0.5,0.5],"evidence":[0.5,0.5],"use_evidence":false,"posterior":{"True":0.055,"False":0.945}}}},{"id":8,"name":"Tuberculosis or cancer","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"vpar":[8,6,7],"levels":["True","False"],"values":[1,0,1,0,1,0,0,1],"prob":[0.5,0.5],"evidence":[0.5,0.5],"use_evidence":false,"posterior":{"True":0.064828,"False":0.935172}}}},{"id":9,"name":"Visit Asia","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"levels":["True","False"],"prob":[0.1,0.99],"vpar":[9],"values":[0.1,0.99],"evidence":[0.5,0.5],"use_evidence":false}}},{"id":10,"name":"Smoke?","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"levels":["True","False"],"prob":[0.5,0.5],"vpar":[10],"values":[0.5,0.5],"evidence":[0.5,0.5],"use_evidence":false}}},{"id":11,"name":"Has bronchitis","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"vpar":[11,10],"levels":["True","False"],"values":[6,4,3,7],"prob":[0.5,0.5],"evidence":[1,0],"use_evidence":false,"posterior":{"True":0.45,"False":0.55}}}},{"id":12,"name":"Postive x-ray","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"vpar":[12,8],"levels":["True","False"],"values":[98,2,5,95],"prob":[0.5,0.5],"evidence":[0.5,0.5],"use_evidence":false,"posterior":{"True":0.11029004,"False":0.88970996}}}},{"id":13,"name":"Dyspnoea","type":"state","specification":{"name":"discrete","type":"distribution","parameters":[],"bbn":{"vpar":[13,8,11],"levels":["True","False"],"values":[9,1,8,2,7,3,1,9],"prob":[0.5,0.5],"evidence":[0.5,0.5],"use_evidence":false,"posterior":{"True":0.4359706,"False":0.5640294}}}}]'
    json_result = eval(parse(text=input$fn)) #eval(parse(text="bayesnet(nodes)"))
    json_result
  })

 })

# Run the application
shinyApp(ui = ui, server = server)

