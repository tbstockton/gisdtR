tnormcpt = function(mu,variance,nTarget,nVpar){
  #' Solve Bayesian Network
  #' @param mu function for mu of the truncated normal distribution.
  #' @param nTarget number of levels of the target node.
  #' @param nVpar vector of numbers of levels of each parent.
  #' @return conditional probability table.
  #' @export
  #' @examples
  #' mu='Staff+Testing'; nVpar=rjson::fromJSON('{"Staff": 5, "Testing": 5}'); nTarget = 5
  #' mu='20*Patrons+10*Reservation'; nVpar=rjson::fromJSON('{"Patrons": 3, "Reservation": 2}'); nTarget = 4
  #' mu='10'; nVpar=0; nTarget = 6; var=1
  #' mu='0.9'; var=0.1; nVpar=1; nTarget = 10;
  #' gisdtR::tnormcpt(mu=.01,var=.1,nTarget=5,nVpar=0)
  #' gisdtR::tnormcpt(mu=mu,var=var,nTarget=nTarget,nVpar=nVpar)
  #' gisdtR::tnormcpt(mu='0.1*Node53+0.1*Node71',variance='0.1',nVpar=rjson::fromJR.versionSON('{"Node53": 3, "Node71": 2}'),nTarget=2)

  expand.grid.tnormcpt = function(n)
  {
    args = lapply(n,function(n)(2*(1:n)-1)/(2*n))
    nargs <- length(n) #length(args <- list(...))
    cargs <- vector("list", nargs)
    names(cargs) = names(n)
    iArgs <- seq_len(nargs)
    rep.fac <- 1L
    d <- lengths(args)
    orep <- prod(d)
    for (i in iArgs) { # i = 1
      x <- args[[i]]
      nx <- length(x)
      orep <- orep/nx
      x <- x[rep.int(rep.int(seq_len(nx), rep.int(rep.fac, nx)), orep)]
      cargs[[i]] <- x
      rep.fac <- rep.fac * nx
    }
    rn <- .set_row_names(as.integer(prod(d)))
    structure(cargs, class = "data.frame", row.names = rn)
  }

  namesVpar = names(nVpar)
  names(namesVpar) = names(nVpar)
  tmeans = expand.grid.tnormcpt(n=nVpar)
  mu.normalizer = max(with(expand.grid(lapply(namesVpar,function(x)c(0,1))),eval(parse(text=mu))))
  mu.normalizer = ifelse(length(nVpar)>1,mu.normalizer,1)
  tsd = ifelse(is.null(variance),sqrt(1/mu.normalizer),sqrt(variance))
  tmeans = with(tmeans,eval(parse(text=mu)))/mu.normalizer
  cpt = sapply(tmeans,function(tmean){
    normalizer = diff(pnorm(c(0,1),tmean,tsd))
    (pnorm((1:nTarget)/nTarget,tmean,tsd)-pnorm((0:(nTarget-1))/nTarget,tmean,tsd))/normalizer
  })
  return(rjson::toJSON(round(as.vector(cpt),4)))
}
