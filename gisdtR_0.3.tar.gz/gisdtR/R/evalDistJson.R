# evalDistJson.R
# Tom Stockton November 2011
# Neptune and Company
evalDistJson = function(dist,fun="random",n=1,probs=seq(0.01,0.99,by=0.01),decode=TRUE,encode=TRUE,data=NULL){
  # dist = '{"type":"distribution","name":"elicit","quantiles":{"x":[0.8,0.9,1,1.3],"p":[0,0.1,0.5,0.9]},"fit":{"name":"lognormal","parameters":{"alpha":2.51822183977105,"beta":6787751.11060974}}}'
  # dist ='{"type":"distribution","name":"elicit","quantiles":{"x":[0.8,0.9,1,1.3],"p":[0,0.1,0.5,0.9]},"fit":{"name":"lognormal","parameters":{"mu":-1.55501666541585,"sigma":0.628399307792101}}}' #,"theta":0.8,"rt":"Inf","loglik":-1.2025625148913,"aic":6.40512502978261}}}'
  # dist ='{"type":"distribution","name":"normal","parameters":{"mean":"150","std":10}}'
  # dist ='{"type":"distribution","name":"lognormal","parameters":{"logmean":"233","logstd":1.75}}'
  # dist ='{"type": "distribution", "name":"lognormal","parameters":{"logmean":"4.4","logsd":"0.15"}}'
  # dist ='{"type": "distribution", "name":"beta","parameters":{"alpha":"1.73","beta":"1.72","min":"0.05","max":"0.15"}}'
  # dist = '{"type":"distribution","name":"beta","parameters":{"alpha":"1.73","beta":"1.72","min":"0.05","max":"0.15"},"origin":"user","class":"dasees","category":"continuous"}'
  # fun="random"  fun="density"   fun="quantile"
  # evalDistJson(dist,fun="density")
  # summary(evalDistJson(dist,n=1000))
  # dist = '{"type":"distribution","name":"elicit","percentiles":{"x":[40.9,68.5,123.7,241,299.65],"p":[0,0.1,0.5,0.9,1]},"fit":{"name":"lognormal","parameters":{"mu":4.64672356066286,"sigma":0.588333404842619,"theta":19.4530448902469,"rt":"Inf"}}}'
  # dist = '{"type":"distribution","name":"elicit","percentiles":{"x":[40.9,68.5,123.7,241,299.65],"p":[0,0.1,0.5,0.9,1]},"fit":{"name":"normal","parameters":{"mu":120,"sigma":10}}}'

  dbetaScaled <- function(x, v=NULL, w=NULL, A=NULL, B=NULL, parameters=NULL, ...)
  {
    if(!is.null(parameters)){
      v <- parameters[1]
      w <- parameters[2]
      A <- parameters[3]
      B <- parameters[4]
    }
    return(gamma(v+w)/(gamma(v)*gamma(w)) * (x-A)^(v-1) * (B-x)^(w-1)/(B-A)^(v+w-1))
  }
  qbetaScaled <- function(p, v=NULL, w=NULL, A=0, B=1, parameters=NULL, ...){
    if(!is.null(parameters)) {
      v <- parameters[1]
      w <- parameters[2]
      A <- parameters[3]
      B <- parameters[4]
    }
    return( qbeta(p,v,w) * (B - A) + A)
  }
  pbetaScaled <- function(x, v=NULL, w=NULL, A=0, B=1, parameters=NULL, ...)
  {
    if(!is.null(parameters)) {
      v <- parameters[1]
      w <- parameters[2]
      A <- parameters[3]
      B <- parameters[4]
    }
    return(integrate(dbetaScaled, lower=A, upper=x, v=v, w=w, A=A, B=B)$value)
  }
  rbetaScaled = function(n, alpha=NULL, beta=NULL, min=0, max=1, parameters=NULL, ...)
  {
    if(!is.null(parameters)) {
      alpha <- parameters[1]
      beta  <- parameters[2]
      min   <- parameters[3]
      max   <- parameters[4]
    }
    rn <- rbeta(n, alpha, beta)
    return(max*rn + min*(1-rn))
  }

  #    qlognormal = function( p,mu,sd,theta=0,rt,... ){
  #      ncons = plnorm( rt - theta, mu, sd )
  #      return( qlnorm(p,mu,sd) - theta )
  #    }
  rlognormal = function(x,mu,sd,theta=0,rt,...){
    return( rlnorm(n, mu, sd) + theta )
  }
  dlognormal = function(x,mu,sd,theta=0,rt,...){
    # x = seq(fromto[1],fromto[2],length=100); mu = 4.646724; sd = 0.5883334
    #ncons = plnorm( rt - theta, mu, sd )
    return( dlnorm(x - theta, mu, sd) )
  }
  #    elicgetcdfpdflnorm = function( pars, dsq ){
  #      ncons = plnorm( pars$rt - pars$theta, pars$mu, pars$sigma )
  #      cdf = ifelse( dsq > pars$rt, 1,
  #                    plnorm(dsq-pars$theta,pars$mu,pars$sigma)/ncons )
  #      pdf = ifelse( dsq > pars$rt, 0,
  #                    dlnorm(dsq-pars$theta,pars$mu,pars$sigma)/ncons )
  #      return(list(cdf=cdf,pdf=pdf))
  #    }

  qlognormal = function(p,mu,sd,theta=0,rt,...){
    return( qlnorm(p, mu, sd) + theta )
  }

  if( decode | is.character(dist) ) { dist = rjson::fromJSON(dist) }
  if(dist$type == "equation" | fun == "equation"){
    ret = with(data,eval(parse(text=dist$equation)))
  }else if(dist$name == "constant"){
    ret = rep(as.numeric(dist$parameters$constant),n)
  }else{
    distName = ifelse(is.null(dist$name),dist$type,dist$name)
    if( distName == "elicit" ) { dist = dist$fit }
    distName = switch(distName, "normal" = "norm","lognormal" = "lognormal","uniform" = "unif", "beta" = "betaScaled")
    qdistName = paste("q",distName,sep="")
    ddistName = paste("d",distName,sep="")
    rdistName = paste("r",distName,sep="")
    #   if( distName == "lnorm" ) {
    #     dist$parameters[["logmean"]] = paste("log(",dist$parameters[["logmean"]],")",sep="")
    #     dist$parameters[["logsd"]]  = paste("log(",dist$parameters[["logsd"]],")",sep="")
    #   }
    if( fun == "density" ){
      fromto = eval(parse(text=paste(qdistName,"(c(0.001,0.999),",paste(unlist(dist$parameters),collapse=","),")",sep="")))
      dens = eval(parse(text=paste(ddistName,"(seq(fromto[1],fromto[2],length=100),",paste(unlist(dist$parameters),collapse=","),")",sep="")))
      summaryStats = signif(eval(parse(text=paste(qdistName,"(c(0.1,0.25,0.50,0.75,0.90),",paste(unlist(dist$parameters),collapse=","),")",sep=""))),4)
      ret = paste('{"data":[',
                  paste(apply(data.frame(
                    prob=dens,
                    level=seq(fromto[1],fromto[2],length=100)),
                    1,rjson::toJSON),
                    collapse=","),'],','
                  "summary":{"p10th":',summaryStats[1],
                  ',"p25th":',summaryStats[2],
                  ',"p50th":',summaryStats[3],
                  ',"p75th":',summaryStats[4],
                  ',"p90th":',summaryStats[5],
                  '}}',
                  sep="")
    }else if( fun == "quantile" ){
      ret = eval(parse(text=paste(qdistName,"(c(",paste(probs,collapse=","),"),",paste(unlist(dist$parameters),collapse=","),")",sep="")))
      if(encode){
        ret  = paste('{"data":[',
                     paste(apply(data.frame(
                       prob=probs, #seq(0.01,0.99,by=0.01),
                       level=signif(ret,6)),
                       1,rjson::toJSON),
                       collapse=","),"]}",sep="")
      }
    }else if( fun == "random" ){
      ret = eval(parse(text=paste(rdistName,"(",n,",",paste(unlist(dist$parameters),collapse=","),")",sep="")))
    }
  }
  return(ret)
}
