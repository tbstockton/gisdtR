montecarlo = function(gnodes,g,nReals=1000){
  #' Transverse a graph solving each node
  #' @param gnodes, each node in the graph with specification attribute (JSON).
  #' @param g, the graph to transverse (JSON).
  #' @param nReals, number of Monte carlo simulations to run.
  #' @return realizations.
  #' @export
  nNodes = length(nodes(g))
  realizations = vector("list",nNodes)
  names(realizations) = nodes(g)
  roots = graph::leaves(g,"in")
  nodesDone = NULL
  while( length(nodesDone) < nNodes ){
    for( thisNode in roots ){ #   thisNode = roots[1]
      nodesDone = c(nodesDone,thisNode)
      if(is.character(gnodes[[thisNode]])){
        realizations[[thisNode]] = evalDistJson(rjson::fromJSON(nodes[[thisNode]])$specification,fun="random",probs=tiles,n=nReals,data=realizations,decode=F,encode=F)
      }else{
        realizations[[thisNode]] = evalDistJson(nodes[[thisNode]],fun="random",probs=tiles,n=nReals,data=realizations,decode=F,encode=F)
      }
    }
    kids = unique(gRbase::children(roots,g))
    roots = kids[unlist(lapply(kids,function(node,nodesDone){ all((gRbase::parents(node,g)) %in% nodesDone )  }, nodesDone ) )]
  }
  return(realizations)
}
