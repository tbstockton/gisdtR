montecarloscenarios = function(gnodes,g,scenarios,nReals=1000,shape="deep",quantiles=seq(0,1,length=11),mix=FALSE){
  #' Loop through scenarios running through the graph solving each node
  #' @param gnodes (JSON).
  #' @param g (JSON).
  #' @param scenarios (JSON).
  #' @param nReals, number of Monte carlo simulations to run.
  #' @param shape, deep or wide
  #' @param quantiles quantiles
  #' @return realizations.
  #' @export

  if(!(class(g) == "graphNEL")){
    g = apply(do.call("rbind",rjson::fromJSON(g)),2,as.numeric)
    g = graph::ftM2graphNEL(cbind(g[,"node_from"],g[,"node_to"]))
  }
  if(is.character(scenarios)){
    scenarios = as.data.frame(do.call("rbind",
                                      rjson::fromJSON(scenarios)
                                      ))
  }



  names(rjson::fromJSON(scenarios))

  theseSims = NULL
  for(thisScenario in names(scenarios)){
    nodeSpec = vector("list",length(nodes(g)))
    names(nodeSpec) = nodes(g)

    for(node in nodes(g)) { #i=1
      nodeSpec[[node]] = rjson::fromJSON(gnodes[[node]])$specification
    }
    scenario = scenarios[[thisScenario]]
    for(node in names(scenario)) { # i = 1
      nodeSpec[[node]]$name = "constant"
      nodeSpec[[node]]$parameters$constant = scenario[[node]]
    }
    thisSim = montecarlo(nodeSpec,g,nReals=nReals)
    if(shape=="deep"){
      for(thisNode in names(thisSim)){
      # sims[[scenario]] =
        tmp = data.frame(node=rep(thisNode,length(thisSim[[thisNode]])),
                   prob=seq(0,1,length=length(thisSim[[thisNode]])),
                   reals=sort(thisSim[[thisNode]]),
                   conditioning=rep(paste(paste(names(scenario),"=",scenario,collapse=", ",sep="")),length(thisSim[[thisNode]]))
        )
        if(mix) tmp = tmp[sample(1:nrow(tmp),nrow(tmp)),]
        theseSims = rbind(theseSims,tmp)
      }
    }else if(shape=="wide"){
      thisSims = as.data.frame(do.call("cbind",thisSim))
      thisSims$Scenario = factor(paste(names(scenario),"=",scenario,collapse=", ",sep=""))
      theseSims = rbind(theseSims,thisSims)
    }else{
      theseSims = rbind(theseSims,
                        data.frame(node=rep(thisNode,length(quantiles)),
                                   prob=quantiles,
                                   reals=quantile(thisSim[[thisNode]],quantiles),
                                   conditioning=rep(paste(paste(names(scenario),"=",scenario,collapse=", ",sep="")),length(quantiles))
                        )
      )
      theseSims = json::toJSON(theseSims)
    }
  }
  return(theseSims)
}
